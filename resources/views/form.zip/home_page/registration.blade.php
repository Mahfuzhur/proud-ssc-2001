@extent('home_page_master')
@section('home_page_main_content')
<div class='main-content'>
  <div class='main-content-wrap'>
    <h1 class="content-header">registration:</h1>
  </div>
  <footer id="site-footer">
    <div class="row">
      <div class="col-sm-6">
        <div class="copyright">&copy; 2018 :  All rights reserved.</div>
      </div>
      <div class="col-sm-6">
        <div class="designed-by pull-right">Designed & Developed By <a href="http://webvisiondigital.com/" target="_blank">@webvisiondigital</a></div>
      </div>
    </div>
  </footer> <!-- site-footer -->
</div><!-- main-content -->
@endsection