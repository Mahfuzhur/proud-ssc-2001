<from action="send" method="post">

    to:<input type="text" name="to">
    message: <textarea name="message" cols="30" rows="10"></textarea>
    <input type="submit" value="Send">
</from>